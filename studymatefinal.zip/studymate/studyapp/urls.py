# from django.urls import path
# from . import views
# from django.contrib.auth import views as auth_views

# urlpatterns = [
#     path('', views.home, name='home'), 
#     path('login/', views.user_login, name='user_login'),  # Routes the root URL to the home view
#     path('signup/', views.user_signup, name='signup'),
#     path('dashboard/',views.dashboard,name='dashboard'),
#     # path('personal_details/', views.personal_details, name='personal_details'),
#     # path('logout/', views.user_logout, name='user_logout'),
#         # Added Logout URL
# ]


from django.urls import path
from . import views


from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('', views.home, name='home'),
    path('signup/', views.user_signup, name='signup'),
    path('personal_details/', views.personal_details, name='personal_details'),
    path('login/', views.user_login, name='user_login'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('logout/', views.user_logout, name='user_logout'),
    path('profile/', views.profile, name='profile'),
    path('ask-question/', views.ask_question, name='ask_question'),
    path('view-doubts/', views.view_doubts, name='view_doubts'),
    path("vote/", views.vote_question, name="vote_question"),
    path('solve-doubt/<int:question_id>/', views.solve_doubt, name='solve_doubt'),
    path('solution/submit/<int:question_id>/', views.submit_solution, name='submit_solution'),
    path('view-solutions/<int:question_id>/', views.view_solutions, name='view_solutions'),
    path('vote-solution/', views.vote_solution, name='vote_solution'),
    path('help/', views.help, name='help'),
    path("save_goal/", views.save_goal, name="save_goal"),
    path("get_goals/", views.get_goals, name="get_goals"),
    path('studygoals/', views.studygoals, name='studygoals'),
    path('history/', views.history_view, name='history'),
                 ]   



if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)