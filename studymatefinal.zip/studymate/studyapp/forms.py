from django import forms
from django.contrib.auth.models import User
from .models import PersonalDetails

class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    confirm_password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']  # Removed 'confirm_password'

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password and confirm_password and password != confirm_password:
            self.add_error("confirm_password", "Passwords do not match!")

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])  # Hash the password
        if commit:
            user.save()
        return user


from django import forms
from .models import PersonalDetails

class PersonalDetailsForm(forms.ModelForm):
    ROLE_CHOICES = [
        ('student', 'Student'),
        ('teacher', 'Teacher'),
    ]

    role = forms.ChoiceField(choices=ROLE_CHOICES, widget=forms.Select(attrs={'class': 'form-control'}))
    student_id = forms.CharField(
        max_length=100, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Student ID'})
    )
    teacher_id = forms.CharField(
        max_length=100, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Teacher ID'})
    )

    class Meta:
        model = PersonalDetails
        fields = ['full_name', 'date_of_birth', 'college_name', 'education_qualification', 'role', 'student_id', 'teacher_id']

    def clean(self):
        cleaned_data = super().clean()
        role = cleaned_data.get("role")
        student_id = cleaned_data.get("student_id")
        teacher_id = cleaned_data.get("teacher_id")

        # Ensure only one of student_id or teacher_id is provided
        if role == 'student' and not student_id:
            self.add_error('student_id', "Student ID is required for students.")
        if role == 'teacher' and not teacher_id:
            self.add_error('teacher_id', "Teacher ID is required for teachers.")

        return cleaned_data


from django import forms
from .models import Solution

class SolutionForm(forms.ModelForm):
    class Meta:
        model = Solution
        fields = ["solution_text", "solution_file"]
